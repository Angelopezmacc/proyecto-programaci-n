﻿t0 = "{0}\n{1}\n{2}".format("en este momento estas solo en casa","1.salir","2.quedarse en casa")
t1 = "{0}\n{1}\n{2}\n{3}".format("antes de salir... Â¿con quien quieres salir?","1.salir con x (tu mejor amigo)","2.salir con y (una amigo que conociste hace poco, pero te agrada)","3.salir solo")                            
t2 = "{0}\n{1}\n{2}\n{3}".format("ahora que decidiste quedarte... Â¿Que haras?", "1.Hablar con tus amigos por chat", "2.Jugar videojuegos con tus amigos","3.jugar videojuegos solo")

def decisiones():
    d0 = int(input(t0))
    if d0 == 1:
        d1 = int(input(t1))
        if d1 == 1:
            pass
        elif d1 == 2:
	    pass
	elif d1 == 3:
	    pass
    elif d0 == 2:
        d2 = int(input(t2))
	if d2 == 1:
            pass
        elif d2 == 2:
	    pass
	elif d2 == 3:
	    pass
        

decisiones()